﻿using GlobalStore.Models.Orders;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GlobalStore.Domain_Logic
{
    public interface iGlobalStoreDomainLogic
    {
        Task<List<Orders>> GetListAsync();
        Task<List<Orders>> GetByIdAsync(int? id);

        Task Create(string url);
    }
}
