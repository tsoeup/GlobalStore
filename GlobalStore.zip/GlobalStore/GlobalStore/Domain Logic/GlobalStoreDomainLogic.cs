﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GlobalStore.Models.Orders;
using GlobalStore.Repository;

namespace GlobalStore.Domain_Logic
{
    public class GlobalStoreDomainLogic : iGlobalStoreDomainLogic
    {
        private readonly GlobalStoreRepository globalStoreRepository;
        public GlobalStoreDomainLogic(GlobalStoreRepository globalStoreRepository)
        {
            this.globalStoreRepository = globalStoreRepository;
        }

        public GlobalStoreDomainLogic()
        {
        }

        public Task<Orders> GetItems()
        {
            throw new NotImplementedException();
        }


        public async Task<List<Orders>> GetListAsync()
        {
            return await globalStoreRepository.GetAsync();
        }

        public async Task<List<Orders>> GetByIdAsync(int? id)
        {
            if (id == null)
                return null;
            else
                return await globalStoreRepository.GetByIdAsync(id);
        }


        public async Task Create(string url)
        {
            Orders orders = new Orders
            {
                GlobalStoreUrl = url
            };

            await globalStoreRepository.Create(orders);
        }

        internal Task Create(object globalStoreUrl)
        {
            throw new NotImplementedException();
        }
    }
}
