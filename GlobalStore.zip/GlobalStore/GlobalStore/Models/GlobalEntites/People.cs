﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace GlobalStore.Models.Orders
{
    public partial class People
    {
        public int ListId { get; set; }

        [DisplayName("Person")]
        public string Column1 { get; set; }

        [DisplayName("Region")]
        public string Column2 { get; set; }
    }
}
