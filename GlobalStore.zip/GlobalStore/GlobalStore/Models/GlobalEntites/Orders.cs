﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace GlobalStore.Models.Orders
{
    public partial class Orders
    {
        [DisplayName("List ID")]
        public int ListId { get; set; }

        [DisplayName("Row ID")]
        public string RowId { get; set; }

        [DisplayName("Order ID")]
        public string OrderId { get; set; }

        [DisplayName("Order Date")]
        public string OrderDate { get; set; }

        [DisplayName("Ship Date")]
        public string ShipDate { get; set; }

        [DisplayName("Ship Mode")]
        public string ShipMode { get; set; }

        [DisplayName("Customer ID")]
        public string CustomerId { get; set; }

        public string Segment { get; set; }

        [DisplayName("Postal Code")]
        public string PostalCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Region { get; set; }
        public string Market { get; set; }

        [DisplayName("Product ID")]
        public string ProductId { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }

        [DisplayName("Product Name")]
        public string ProductName { get; set; }
        public string Sales { get; set; }
        public string Quantity { get; set; }
        public string Discount { get; set; }
        public string Profit { get; set; }

        [DisplayName("Shipping Cost")]
        public string ShippingCost { get; set; }

        [DisplayName("Order Priority")]
        public string OrderPriority { get; set; }
        public object GlobalStoreUrl { get; internal set; }
    }
}
