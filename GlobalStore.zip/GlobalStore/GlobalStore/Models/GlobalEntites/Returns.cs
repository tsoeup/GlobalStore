﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace GlobalStore.Models.Orders
{
    public partial class Returns
    {
        public string Returned { get; set; }

        [DisplayName("Order ID")]
        public string OrderId { get; set; }
        public string Region { get; set; }
    }
}
