﻿using GlobalStore.Data;
using GlobalStore.Models.Orders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GlobalStore.Repository
{

        public class GlobalStoreRepository : IGlobalStoreRepository
        {
            private readonly Project3Context project3Context;
            public GlobalStoreRepository()
            {
                this.project3Context = new Project3Context();
            }

            public async Task Create(Orders orders)
            {
                var result = await project3Context.Set<Orders>().AddAsync(orders);
                await project3Context.SaveChangesAsync();
            }

            public async Task<List<Orders>> GetAsync()
            {
                return await project3Context.Orders.ToListAsync();
            }

            public async Task<List<Orders>> GetByCountryAsync(string country)
            {
                return await project3Context.Orders.Where(m => m.Country == country).ToListAsync();
            }

            public async Task<List<Orders>> GetByIdAsync(int? id)
            {
                return await project3Context.Orders.Where(m => m.ListId == id).ToListAsync();
            }
        }
}
