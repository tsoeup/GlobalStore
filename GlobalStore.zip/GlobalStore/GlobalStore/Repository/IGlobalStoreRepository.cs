﻿using GlobalStore.Models.Orders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GlobalStore.Repository
{
    interface IGlobalStoreRepository
    {
        Task<List<Orders>> GetAsync();
        Task<List<Orders>> GetByIdAsync(int? id);
        Task Create(Orders africanStartup);
    }
}
